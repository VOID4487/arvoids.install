const readline = require('readline');
const { spawnSync } = require('child_process');
const gradient = require('gradient-string');

function displayMenu() {
  console.log(gradient.mind(`
  ╔═╦══════════════════════════════════╗
  ╠═╣      Arvoids Sub Menu  ::        ║
  ║ ╠══════════════════════════════════╣
  ║ ╣〘1〙Manage Addons                ║
  ╠ ║〘2〙System Info                  ║ 
  ║ ╣〘3〙Raw System Info Data         ║
  ╠ ║〘4〙Kill Server                  ║ 
  ║ ╣〘5〙Kill CPU processes           ║
  ╚═╩══════════════════════════════════╝
          [〘6〙Exit This Panel]
  `));
}

function executeTool(option) {
  let toolPath = '';
  switch (option) {
    case 1:
      toolPath = './utils/addonsmanager';
      break;
    case 2:
      toolPath = './utils/.info/parsedinfo';
      break;
    case 3:
      toolPath = './utils/.info/rawinfo';
      break;
    case 4:
      toolPath = './utils/bash/kill.sh';
      break;
    case 5:
      toolPath = './utils/bash/killcpu.sh';
      break;
    case 6:
      console.log(gradient.mind('Exiting...'));
      process.exit(0);
      break;
    default:
      console.log(gradient.mind('[ARVOIDS | SUB-SHELL] >> Invalid option.'));
      return;
  }

if (toolPath.endsWith('.sh')) {
    const shellProcess = spawnSync('sh', [toolPath], { stdio: 'inherit' });

    if (shellProcess.error) {
      console.error(gradient.mind(`[ARVOIDS | SUB-SHELL] >> Error starting shell script: ${shellProcess.error}`));
    } else {
      console.log(gradient.mind(`[ARVOIDS | SUB-SHELL] >> Shell script exited with code ${shellProcess.status}`));
    }
  } else {
    const toolProcess = spawnSync('node', [toolPath], { stdio: 'inherit' });

    if (toolProcess.error) {
      console.error(gradient.mind(`[ARVOIDS | SUB-SHELL] >> Error starting tool: ${toolProcess.error}`));
    } else {
      console.log(gradient.mind(`[ARVOIDS | SUB-SHELL] >> Tool exited with code ${toolProcess.status}`));
    }
  }

  displayMenu();
}
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

displayMenu();

rl.on('line', (input) => {
  const choice = parseInt(input);

  if (isNaN(choice)) {
    console.log(gradient.mind('[ARVOIDS | SUB-SHELL] >> Invalid Response'));
  } else {
    executeTool(choice);
  }
});
