const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');
const readline = require('readline');
const Table = require('cli-table3');
const gradient = require('gradient-string');

const addonActivePath = 'server/modules/definitions/addons';
const inactivePath = 'utils/.addons';

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function listAddons() {
    const table = new Table({
        head: ['Addon', 'Addon State']
    });

    function getAddonState(addonName) {
        const activeAddonPath = path.join(addonActivePath, addonName);
        const inactiveAddonPath = path.join(inactivePath, addonName);

        const isActive = fs.existsSync(activeAddonPath);
        const isInactive = fs.existsSync(inactiveAddonPath);

        if (isActive) {
            return 'Active';
        } else if (isInactive) {
            return 'Inactive';
        } else {
            return 'Not Found';
        }
    }

    let activeAddons = [];
    let inactiveAddons = [];
    try {
        activeAddons = fs.readdirSync(addonActivePath);
        inactiveAddons = fs.readdirSync(inactivePath);
    } catch (err) {
        console.error('Error reading addon directories:', err);
        return;
    }

    const allAddons = [...new Set([...activeAddons, ...inactiveAddons])];
    if (allAddons.length === 0) {
        console.log('No addons found.');
    } else {
        allAddons.forEach(addon => {
            const state = getAddonState(addon);
            table.push([addon, state]);
        });

        console.log(table.toString());
    }
}

function toggleAddon(addonName) {
    const activeAddonPath = path.join(addonActivePath, addonName);
    const inactiveAddonPath = path.join(inactivePath, addonName);

    const isActive = fs.existsSync(activeAddonPath);
    const isInactive = fs.existsSync(inactiveAddonPath);

    if (!isActive && !isInactive) {
        console.log(gradient.mind('[ERROR!!]: Addon not found in either directory.'));
        askUser();
        return;
    }

    const command = isActive
        ? `mv ${activeAddonPath} ${inactiveAddonPath}`
        : `mv ${inactiveAddonPath} ${activeAddonPath}`;

    exec(command, (error, stdout, stderr) => {
        if (error) {
            console.error(`Error toggling addon: ${error.message}`);
            askUser();
            return;
        }

        const message = isActive ? `Addon '${addonName}' deactivated.` : `Addon '${addonName}' activated.`;
        console.log(message);
        listAddons();
        askUser();
    });
}

function askUser() {
    rl.question(gradient.mind('[INFO!!] Enter an addon name to toggle its state or type "exit" to quit: '), answer => {
        if (answer.toLowerCase() === 'exit') {
            rl.close();
            return;
        }

        toggleAddon(answer.endsWith('.js') ? answer : `${answer}.js`);
    });
}

// Initial display of addons
listAddons();

// Start asking for user input
askUser();

// Close readline interface on exit
rl.on('close', () => {
    console.log('Addon manager closed.');
});
