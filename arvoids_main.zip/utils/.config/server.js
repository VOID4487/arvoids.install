  const express = require('express');
  const bodyParser = require('body-parser');
  const fs = require('fs');
  const path = require('path');

  const app = express();
  const PORT = 443;

  app.set('view engine', 'ejs');
  app.set('views', path.join(__dirname, 'views'));

  app.use(bodyParser.json());
  app.use(bodyParser.urlencoded({ extended: true }));

  app.use('/utils', express.static(path.join(__dirname, 'utils')));

  app.get('/conf', (req, res) => {
      try {
          const configPath = path.join(__dirname, '..', '..', 'server', 'config.js');
          const configData = require(configPath);

          res.render('configEditor', { configData });
      } catch (error) {
          console.error(error);
          res.status(500).send(`Error loading configuration editor: ${error.message}`);
      }
  });

  app.post('/updateConfig', (req, res) => {
      try {
          const { body } = req;

          const configPath = path.join(__dirname, '..', '..', 'server', 'config.js');
          let configData = require(configPath);

          Object.keys(body).forEach(key => {
              const value = body[key];
              if (configData.hasOwnProperty(key)) {
                  if (value === 'true' || value === 'false') {
                      configData[key] = value === 'true';
                  } else if (typeof configData[key] === 'string') {
                      configData[key] = value;
                  }
              }
          });

          const updatedConfig = Object.keys(configData)
              .map(key => `${key}: ${typeof configData[key] === 'boolean' ? configData[key] : `'${configData[key]}'`}`)
              .join(',\n  ');

          const updatedConfigFile = `module.exports = {\n  ${updatedConfig}\n};`;

          fs.writeFileSync(configPath, updatedConfigFile, 'utf8');

          res.sendStatus(200);
      } catch (error) {
          console.error(error);
          res.status(500).send(`Error updating configuration: ${error.message}`);
      }
  });

  app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
  });
