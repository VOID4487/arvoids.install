const express = require('express');
const app = express();
const path = require('path');

const port = process.env.PORT || 5014;
const editorURL = '/';
const localServerURL = `https://private.arvoids.repl.co${editorURL}`;
const staticFilesPath = path.join(__dirname, 'osa-editor');

app.use('/', express.static(path.join(__dirname, '../.misc-host')));

app.use((req, res, next) => {
  console.log(`[${new Date().toLocaleString()}] 404 - Not Found: ${req.method} ${req.originalUrl}`);
  res.status(404).send('404 - Not Found');
});

app.use(editorURL, express.static(staticFilesPath));

app.listen(port, () => {
  console.log(`PORT${port}`);
  console.log(`Access at: ${localServerURL}`);
});
console.log('server running...');