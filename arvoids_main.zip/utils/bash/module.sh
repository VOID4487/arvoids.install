#!/bin/bash
/usr/bin/npm list