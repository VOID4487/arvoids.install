const readline = require('readline');
const { spawnSync } = require('child_process');
const gradient = require('gradient-string');

function displayMenu() {
  console.log(gradient.mind(`
  ╔═╦══════════════════════════════════╗
  ╠═╣      Arvoids Start Menu  ::      ║
  ║ ╠══════════════════════════════════╣
  ╠ ║〘1〙Arvoids Server               ║                        
  ║ ╣〘2〙Editor Server                ║           
  ╠ ║〘3〙Filesystem Pipe              ║ 
  ║ ╣〘4〙Manage Addons                ║
  ╠ ║〘5〙System Info                  ║ 
  ║ ╣〘6〙Raw System Info Data         ║
  ╠ ║〘7〙Installed Dependencies       ║ 
  ║ ╣〘8〙Edit Server Configuration    ║
  ╠ ║〘9〙Start .ms Socket             ║ 
  ╚═╩══════════════════════════════════╝
  ╔═╦════════════════════════════════╦═╗
  ╠═╣     Current Providers ::       ╠═╣
  ╠═╬════════════════════════════════╬═╣
  ╠═╣       VOID Development         ╠═╣
  ╚═╩════════════════════════════════╩═╝

  `));
}

function executeTool(option) {
  let toolPath = '';
  switch (option) {
    case 1:
      toolPath = './server/index';
      break;
    case 2:
      toolPath = './utils/editor';
      break;
    case 3:
      toolPath = './utils/pipe';
      break;
    case 4:
      toolPath = './utils/addonsmanager';
      break;
    case 5:
      toolPath = './utils/.info/parsedinfo';
      break;
    case 6:
      toolPath = './utils/.info/rawinfo';
      break;
    case 7:
      toolPath = 'utils/bash/module.sh';
      break;
    case 8:
      toolPath = 'utils/config.ui.js';
      break;
    case 9:
      toolPath = 'utils/mischost.js';
      break;
    default:
      console.log(gradient.mind('[ERROR] >> Response Integer Not On Menu! '));
      return;
  }

  const toolProcess = spawnSync('node', [toolPath], { stdio: 'inherit' });

  if (toolProcess.error) {
    console.error(gradient.mind(`Error starting tool: ${toolProcess.error}`));
  } else {
    console.log(gradient.mind(`[INFO] >> Tool exited with code ${toolProcess.status} !`));
  }

  displayMenu();
}

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

displayMenu();

rl.on('line', (input) => {
  const choice = parseInt(input);

  if (isNaN(choice)) {
    console.log(gradient.mind('[ERROR] >> Invalid Response ; Reconfirm!'));
  } else {
    executeTool(choice);
  }
});
