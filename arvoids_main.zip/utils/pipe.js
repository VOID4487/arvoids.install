const http = require('http');
const fs = require('fs');
const path = require('path');
const gradient = require('gradient-string');

const username = "void@arvoids";
const password = process.env.password;

const server = http.createServer((req, res) => {
    const basePath = './';
    const filePath = path.join(basePath, req.url);

    const authHeader = req.headers['authorization'];
    if (!authHeader || authHeader !== `Basic ${Buffer.from(`${username}:${password}`).toString('base64')}`) {
        res.writeHead(401, {'Content-Type': 'text/plain', 'WWW-Authenticate': 'Basic realm="Restricted Area"'});
        res.end('Credentails Are Invalid');
        return;
    }

    fs.stat(filePath, (err, stats) => {
        if (err) {
            res.writeHead(404, {'Content-Type': 'text/plain'});
            res.end('File not found');
            return;
        }
        if (stats.isDirectory()) {
            fs.readdir(filePath, (err, files) => {
                if (err) {
                    res.writeHead(500, {'Content-Type': 'text/plain'});
                    res.end('Internal Server Error');
                    return;
                }
                res.writeHead(200, {'Content-Type': 'text/html'});
                res.write('<!DOCTYPE html><html><head><title>Directory Contents</title>');
                res.write('<style>body { font-family: Arial, sans-serif; background-color: #333; color: #fff; } ul { list-style-type: none; padding-left: 0; } li { margin-bottom: 5px; } a { text-decoration: none; color: #007bff; } a:hover { text-decoration: underline; } .file-viewer { font-family: monospace; padding: 20px; background-color: #222; border: 1px solid #ccc; color: #fff; }</style>');
                res.write('</head><body>');
                res.write('<h1>Directory Contents</h1>');
                res.write('<ul>');
                files.forEach(file => {
                    res.write(`<li><a href="${path.join(req.url, file)}">${file}</a></li>`);
                });
                res.write('</ul>');
                res.write('</body></html>');
                res.end();
            });
        } else {
            const fileContent = fs.readFileSync(filePath, 'utf-8');
            res.writeHead(200, {'Content-Type': 'text/html'});
            res.write('<!DOCTYPE html><html><head><title>File Viewer</title>');
            res.write('<style>body { font-family: Arial, sans-serif; background-color: #333; color: #fff; } .file-viewer { font-family: monospace; padding: 20px; background-color: #222; border: 1px solid #ccc; color: #fff; }</style>');
            res.write('</head><body>');
            res.write('<div class="file-viewer">');
            res.write(`<pre>${fileContent}</pre>`);
            res.write('</div>');
            res.write('</body></html>');
            res.end();
        }

        console.log(gradient.mind(`[INFO] >> ${req.method}, ${req.url}`));
    });
});

const PORT = 443;
server.listen(PORT, () => {
    console.log(gradient.mind(`[INFO] >> Opened PIPE on Port ${PORT}!`));
});
