const express = require("express");
const fs = require("fs");
const gradient = require('gradient-string');

const app = express();
const PORT = 3000;

const excludedKeys = [
  "LEVEL_SKILL_POINT_FUNCTION",
  "WELCOME_MESSAGE",
  "BOT_SKILL_UPGRADE_CHANCES",
  "BOT_CLASS_UPGRADE_CHANCES",
  "FOOD_TYPES",
  "FOOD_TYPES_NEST",
  "ENEMY_TYPES_NEST",
  "BOSS_TYPES",
  "GAMEMODE_NAME_PREFIXES",
  "GAME_MODES",
  "ROOM_SETUP",
];

const textKeys = [
  "host",
  "GAME_MODES",
  "ROOM_SETUP",
  "DEFAULT_FILE",
  "WINDOW_NAME",
  "ARENA_TYPE",
  "MODE",
];

const specialFormatKeys = {
  GAME_MODES: true,
  ROOM_SETUP: true,

};

app.set("view engine", "ejs");
app.use(express.static("server/views"));

app.get("/", (req, res) => {
  try {
    const configData = require("../server/config.js");
    const filteredConfig = filterExcludedKeys(configData);
    res.render("config", { configData: filteredConfig });
  } catch (err) {
    console.error("Error reading config file:", err);
    res.status(500).send("Internal Server Error");
  }
});

app.post("/update-config", express.json(), (req, res) => {
  const { key, value } = req.body;

  if (excludedKeys.includes(key)) {
    res.status(403).send("Forbidden: Key is excluded from modification");
    return;
  }

  try {
    let configContent = fs.readFileSync("server/config.js", "utf-8");
    const updatedContent = updateConfigValue(configContent, key, value);
    fs.writeFileSync("server/config.js", updatedContent);
    res.status(200).send("Config updated successfully");
  } catch (err) {
    console.error("Error updating config:", err);
    res.status(500).send("Internal Server Error");
  }
});

function filterExcludedKeys(configData) {
  const filteredConfig = { ...configData };
  excludedKeys.forEach((key) => {
    delete filteredConfig[key];
  });
  return filteredConfig;
}

function updateConfigValue(configContent, key, value) {
  const lines = configContent.split("\n");
  const updatedLines = lines.map((line) => {
    if (line.includes(key) && !excludedKeys.includes(key)) {
      const parts = line.split(":");
      if (parts.length > 1) {
        const trimmedKey = parts[0].trim();
        if (trimmedKey === key) {
          let oldValue = parts.slice(1).join(":").trim();
          let newValue = value;

          const containsNumber = /\d/.test(value);
          const isTextValue = textKeys.includes(key) && !containsNumber;
          const isBoolean =
            value === "true" || value === "false" || !isNaN(value);

          if (!isBoolean) {

            newValue = value;
          }

          if (!isTextValue) {

            newValue = `"${value}"`;
          }

          if (isBoolean) {

            return `${trimmedKey}: ${value},`;
          }

          if (specialFormatKeys[key]) {

            const formattedValue = JSON.stringify(JSON.parse(value));
            return `${trimmedKey}: '${formattedValue}',`;
          }

          return `${trimmedKey}: '${newValue}',`;
        }
      }
    }
    return line;
  });
  return updatedLines.join("\n");
}

app.listen(PORT, () => {
  console.log(gradient.mind(`Editor >> [config.js] running on Port[${PORT}]`));
});
