let {sockets} = require('../../network/sockets.js');
const fs = require('fs');
const path = require('path');
let oldConnect = sockets.connect;

let clients = undefined;
let players = undefined;
let disconnections = undefined;

let configobj;
let classbro;
let classes = {};


var inited = false;
var rootobjbro = {};
var maxpage = 1;

const TANKS_PER_PAGE = 15;

function sabotagefunc(){
    //console.log(eval('this'));
    clients = eval('this').clients;;
    players = eval('this').players;
    disconnections = eval('this').disconnections;

}



sockets.connect = function(socket, req){
    global.bromess = socket;
   sabotagefunc.apply(sockets,[]);
   /*setTimeout(()=>{

    if(typeof configobj.isUsingDevTanksUtils === "undefined"){
        try{
            configtxt = fs.readFileSync(path.resolve(__dirname+'/../../../config.js')).toString();
            if(configtxt.includes("isUsingDevTankUtils"))
            configtxt = configtxt.slice(0,configtxt.lastIndexOf('}')-1) + '\n,isUsingDevTankUtils: true }' ;
            configobj.isUsingDevTanksUtils = true;
            fs.writeFileSync(__dirname+'/../../../config.js',configtxt,{flag: "w"})
        }catch(err){
            console.error("[UltimateDevMenu] error reading or saving to config.js!!!", err);
        }
     }  
   },0);*/


   oldConnect.apply(sockets,[socket,req]);


    renderClassObjectsWithoutLevel();
    inited = true;


   /*
   let oldmsghandler = socket.listeners("message")[0]
   socket.removeAllListeners(oldmsghandler);
   socket.on('message', function(message){
        // Only accept binary
        if (!(message instanceof ArrayBuffer)) {
            socket.kick("Non-binary packet.");
            return 1;
        }
        // Decode it
        let m = [...protocol.decode(message)];
        // Make sure it looks legit
        if (m === -1) {
            socket.kick("Malformed packet.");
            return 1;
        }
        // Log the message request

        // Remember who we are
        let player = socket.player;
        // Handle the request
        if (socket.resolveResponse(m[0], m)) {
            return;
        }
        oldmsghandler.apply(null,[message, socket]);
   });*/

   //dont let taureon process the dev key and inject our code instead
   //taureon you see this? lol i bet you dont cuz this is trash addon anyway

   //i suck at code and taureon is js god
   //i am forever noob
   socket.awaiting['0'] = {
    callback: (id,packet)=>{
        if(!socket.permissions || (socket.permissions.class !== "developer" && !socket.permissions.UltraDevMenu)){
            return;
        }
        //console.log(Class.UltimateDevMenu);
        socket.player.body.define({ RESET_UPGRADES: true }); 


        if(global.c.MENU_PAGES_MODE){
            socket.player.body.sendMessage("Welcome to dev menu!\nThis menu can be confusing but each one developer tank\nis a page!\n\nclick on developer tanks = switch page!!!!");
            socket.player.body.define(Class.UltimateDevMenu);
        }else {
            socket.player.body.define(Class.DevUtilPage1);
            socket.in_ultimate_menu = true;
            socket.ultimate_menu_page = 1;
            delete socket.awaiting['U'];
            socket.awaiting['U'] = {
                callback: function(packet){
                    if(typeof socket.player.body.upgrades[packet[1]] === "undefined"){
                        socket.player.body.define({ RESET_UPGRADES: true }); 
                        socket.player.body.define(Class["DevUtilPage"+socket.ultimate_menu_page-1]); 
                        socket.ultimate_menu_page -=1;

                        return;
                    }
                    let type = socket.player.body.upgrades[packet[1]].class;

                    if(type === Class['NextPageUltimateDevTankMenu'] ){
                             socket.player.body.define({ RESET_UPGRADES: true }); 


                            //console.log("upgrading to","DevUtilPage"+socket.ultimate_menu_page);

                           // console.log("last checked: "+Math.min(socket.ultimate_menu_page+1,maxpage)+" is "+(Class["DevUtilPage"+Math.min(socket.ultimate_menu_page+1,maxpage)].UPGRADES_TIER_0.length));
                            if(Class["DevUtilPage"+Math.min(socket.ultimate_menu_page+1,maxpage)].UPGRADES_TIER_0.length === 0){

                                socket.player.body.define(Class["DevUtilPage"+socket.ultimate_menu_page]);
                            }else{
                                socket.ultimate_menu_page = Math.min(socket.ultimate_menu_page+1,maxpage);
                                socket.player.body.define(Class["DevUtilPage"+socket.ultimate_menu_page]);
                            }

                    }else if(type === Class['LastPageUltimateDevTankMenu'] ){
                            socket.player.body.define({ RESET_UPGRADES: true }); 
                            socket.ultimate_menu_page = Math.max(socket.ultimate_menu_page-1,1);
                            //console.log("downgraded to "+"DevUtilPage"+socket.ultimate_menu_page);
                            socket.player.body.define(Class["DevUtilPage"+socket.ultimate_menu_page]);
                    }else{
                        delete socket.awaiting['U'];
                        delete socket.in_ultimate_menu;
                        delete socket.ultimate_menu_page;
                        if (packet.length !== 2) {
                            socket.kick("Ill-sized upgrade request.");
                            return 1;
                        }
                        // Get data
                        let upgrade = packet[0];
                        // Verify the request
                        // Upgrade it
                        if (socket.player.body != null) {
                            //console.log("ayo upgrading?? ",upgrade);
                            if(type !== undefined){
                                socket.player.body.define({ RESET_UPGRADES: true }); 
                                socket.player.body.define(type);
                            }

                          //  socket.player.body.upgrade(upgrade); // Ask to upgrade
                        }
                    }
                },
                timeout: setTimeout(()=>{
                    return;
                },0)
            };
        }
        //console.log("did it work?");
     },
    timeout: setTimeout(() => {
        //this is simply useless.simply wont happen.
        return;
        console.log("legenary taureon", options.timeout);
        console.log("Socket did not respond to the eval packet, kicking...");
        socket.kick("Did not comply with the server's protocol.");
    }, 1),
};

//stop timeouting me man, its annoying i dont even need this function
   /*socket.awaitResponse({packet: '0',timeout: Number.MAX_VALUE-1},(id,packet)=>{
      socket.player.body.define({ RESET_UPGRADES: true });
      socket.player.body.define(Class.UltimateDevMenu);
   });*/

}

function renderClassObjectsWithoutLevel(){
    var rootobj = {};
    var index = 0;
    var page = 1;

    rootobj["DevUtilPage"+page] = JSON.parse(JSON.stringify(Class.developer));
    rootobj["DevUtilPage"+page].LABEL = "DevUtilPage"+page;
    rootobj["DevUtilPage"+page].UPGRADES_TIER_0 = [];   

    var isLastUseless = false;
    for(var key of Object.keys(Class)){
        isLastUseless = false;
        if(!Class[key].LABEL|| key.includes("miscTest") || key === "colorMan"){
            //screw this tank, always crash 
            continue;
        }
        rootobj["DevUtilPage"+page].UPGRADES_TIER_0.push(key);
        isLastUseless = false;

        index++;
        if(index % TANKS_PER_PAGE == 0) {
            rootobj["DevUtilPage"+page].UPGRADES_TIER_0.push("NextPageUltimateDevTankMenu")
            page++;
            rootobj["DevUtilPage"+page] = JSON.parse(JSON.stringify(Class.developer));
            rootobj["DevUtilPage"+page].LABEL = "DevUtilPage"+page;
            rootobj["DevUtilPage"+page].UPGRADES_TIER_0 = [];
            rootobj["DevUtilPage"+page].UPGRADES_TIER_0.push("LastPageUltimateDevTankMenu")
            isLastUseless = true;
        }
    }

    if(isLastUseless){
        delete rootobj["DevUtilPage"+page];
        maxpage--;
    }

   let valuesbro = Object.values(rootobj);
    //if(isLastUseless){
      //  delete rootobj["DevUtilPage"+page];
     //   page -=1;

    //}



   // let valuesbro = Object.values(rootobj);
    valuesbro[valuesbro.length-1].UPGRADES_TIER_0 = valuesbro[valuesbro.length-1].UPGRADES_TIER_0.slice(0, valuesbro[valuesbro.length-1].UPGRADES_TIER_0.LENGTH-1)

    //console.log(rootobj);
    for(var [key,value] of Object.entries(rootobj)){
        Class[key] = value;
    }
    maxpage = page;
    //console.log("max pages", maxpage);
    rootobjbro = rootobj;

}

function renderClassObjectsWithLevel(rootbro = undefined,level = 1){

   var pages = 1;
   var developerobj = JSON.parse(JSON.stringify(Class.developer));
   for(var key in developerobj){
    if(key.includes("UPGRADES")){
        delete developerobj[key];
    }
   }
   var index = 0;
   //console.log("How many tanks are there?", Object.keys(Class).length);
   if(!rootbro){
     let rootobj = {};
     rootobj.DevUtilPage1Level1 = JSON.parse(JSON.stringify(developerobj));
     rootobj.DevUtilPage1Level1.LABEL = "DevUtilPage1Level"+level;
     rootobj.DevUtilPage1Level1.UPGRADES_TIER_0 = [];

     for (let tankkey of Object.keys(Class)){
        let pageobj= rootobj["DevUtilPage"+pages+"Level"+level];
        pageobj.UPGRADES_TIER_0.push(tankkey);

        index++;
        if(index % TANKS_PER_PAGE == 0){
            pages++;
            rootobj["DevUtilPage"+pages+"Level"+level] = JSON.parse(JSON.stringify(developerobj));
            rootobj["DevUtilPage"+pages+"Level"+level].LABEL = "DevUtilPage"+pages+"Level"+level;
            rootobj["DevUtilPage"+pages+"Level"+level].UPGRADES_TIER_0 = [];
            //index = 0;
        }
     }
     //console.log("level "+level+" returned with pages "+pages);
     if(pages > TANKS_PER_PAGE){
       var totallevel = renderClassObjectsWithLevel(rootobj,++level);
     }
     let UltimateDevMenu = JSON.parse(JSON.stringify(developerobj));
     UltimateDevMenu.LABEL = "UltimateDevMenu";
     UltimateDevMenu.UPGRADES_TIER_0 = [];

     for(let [key,value]of Object.entries(rootobj)){
        if(totallevel){
            if(key.endsWith(totallevel)){
                UltimateDevMenu.UPGRADES_TIER_0.push(key);
                console.log(key);
            }
        }else{
            UltimateDevMenu.UPGRADES_TIER_0.push(key);

        }
        Class[key] = value;
     }

     Class.UltimateDevMenu = UltimateDevMenu;

   }else{
    rootbro["DevUtilPage1Level"+level] = JSON.parse(JSON.stringify(developerobj));
    rootbro["DevUtilPage1Level"+level].LABEL = "DevUtilPage1Level"+level;
    rootbro["DevUtilPage1Level"+level].UPGRADES_TIER_0 = [];
    for(let page of Object.keys(rootbro)){
        if(!page.endsWith("Level"+(level-1))){

            continue;
        }
        let pageobj= rootbro["DevUtilPage"+pages+"Level"+level];
        pageobj.UPGRADES_TIER_0.push(page);
        index++;
        if(index % TANKS_PER_PAGE == 0){
            pages++;
            rootbro["DevUtilPage"+pages+"Level"+level] = JSON.parse(JSON.stringify(developerobj));
            rootbro["DevUtilPage"+pages+"Level"+level].LABEL = "DevUtilPage"+pages+"Level"+level;
            rootbro["DevUtilPage"+pages+"Level"+level].UPGRADES_TIER_0 = [];
            //index = 0;
        }
    }



    //console.log("level "+level+" returned with pages "+pages);

    if(pages > TANKS_PER_PAGE){
        let lol = renderClassObjectsWithLevel(rootbro,++level);
        //console.log("returning ",lol);
       return lol;
    }
    //console.log("returning ", level)
    return level;



   }

}

const ac = new AbortController();
module.exports = ({Config,Class,Events})=>{
    //console.log(Config);
   configobj = Config;
   classbro = Class;

   Class.LastPageUltimateDevTankMenu= {
    PARENT: ["genericTank"],
    LABEL: "Last Page",
    DANGER: 6,
    GUNS: [
        {
            POSITION: [21, 14, 1, 0, 0, 0, 0],
            PROPERTIES: {
                //SHOOT_SETTINGS: combineStats([g.basic, g.pound, g.destroy]),
                TYPE: "bullet"
            },
        },
    ],
};

   Class.NextPageUltimateDevTankMenu= {
    PARENT: ["genericTank"],
    LABEL: "Next Page",
    DANGER: 7,
    GUNS: [
        {
            POSITION: [20.5, 19.5, 1, 0, 0, 0, 0],
            PROPERTIES: {
                //SHOOT_SETTINGS: combineStats([g.basic, g.pound, g.destroy, g.anni]),
                TYPE: "bullet"
            },
        },
    ],
};


};