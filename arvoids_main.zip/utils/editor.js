const express = require('express');
const app = express();
const path = require('path');

const port = process.env.PORT || 5014;
const editorURL = '/editor';
const localServerURL = `https://private.arvoids.repl.co${editorURL}`;
const staticFilesPath = path.join(__dirname, 'osa-editor');

app.use('/editor', express.static(path.join(__dirname, 'misc/editor/osa-editor')));

app.get('/', (req, res) => {
  res.send(`
  
  <a href="https://private.arvoids.repl.co/editor">https://private.arvoids.repl.co/editor</a>
  
  `);
});

app.use((req, res, next) => {
  console.log(`[${new Date().toLocaleString()}] 404 - Not Found: ${req.method} ${req.originalUrl}`);
  res.status(404).send('404 - Not Found');
});

app.use(editorURL, express.static(staticFilesPath));

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
  console.log(`Access the editor at: ${localServerURL}`);
});
console.log('Editor server running...');