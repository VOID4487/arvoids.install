const os = require('os');
const si = require('systeminformation');
const { exec } = require('child_process');
const Table = require('cli-table3');
Table.prototype.charLength = function (str) {
  const result = [...str.matchAll(/(?<=\u001b\[).+?(?=[a-zA-Z])/g)];
  return str.length - result.length * 9;
};

(async () => {
  try {
    const osInfo = await si.osInfo();
    const bios = await si.bios();
    const cpu = await si.cpu();
    const mem = await si.mem();
    const disks = await si.diskLayout();
    const battery = await si.battery();
    const networkInterfaces = os.networkInterfaces();
    const processList = await si.processes();
    const temperatures = await si.cpuTemperature();

    const osTable = new Table({ head: ['Category', 'Information'], colWidths: [30, 50], wordWrap: true });
    osTable.push(['Platform', osInfo.platform], ['Distribution', osInfo.distro], ['Release', osInfo.release], ['Kernel Version', osInfo.kernel]);

    const biosTable = new Table({ head: ['Category', 'Information'], colWidths: [30, 50], wordWrap: true });
    biosTable.push(['Vendor', bios.vendor], ['Version', bios.version]);

    const cpuTable = new Table({ head: ['Category', 'Information'], colWidths: [30, 50], wordWrap: true });
    cpuTable.push(['Manufacturer', cpu.manufacturer], ['Brand', cpu.brand], ['Cores', cpu.cores], ['Speed', cpu.speed + ' GHz']);

    const memTable = new Table({ head: ['Category', 'Information'], colWidths: [30, 50], wordWrap: true });
    memTable.push(['Total Memory', (mem.total / (1024 ** 3)).toFixed(2) + ' GB'], ['Free Memory', (mem.free / (1024 ** 3)).toFixed(2) + ' GB']);

    const disksTable = new Table({ head: ['Category', 'Information'], colWidths: [30, 50], wordWrap: true });
    disks.forEach((disk, index) => {
      disksTable.push([`Disk ${index + 1} - Name`, disk.name], [`Disk ${index + 1} - Type`, disk.type], [`Disk ${index + 1} - Size`, (disk.size / (1024 ** 3)).toFixed(2) + ' GB']);
    });

    const batteryTable = new Table({ head: ['Category', 'Information'], colWidths: [30, 50], wordWrap: true });
    if (battery.hasbattery) {
      batteryTable.push(['Manufacturer', battery.manufacturer], ['Model', battery.model], ['Capacity', battery.capacity], ['Status', battery.ischarging ? 'Charging' : 'Discharging']);
    }

    const networkTable = new Table({ head: ['Category', 'Information'], colWidths: [30, 50], wordWrap: true });
    Object.keys(networkInterfaces).forEach((iface) => {
      networkInterfaces[iface].forEach((details) => {
        networkTable.push([`${iface} - ${details.family}`, details.address]);
      });
    });

    const processTable = new Table({ head: ['Category', 'Information'], colWidths: [30, 50], wordWrap: true });
    processTable.push(['Number of Processes', processList.all], ['Running', processList.running], ['Sleeping', processList.sleeping]);

    const tempTable = new Table({ head: ['Category', 'Information'], colWidths: [30, 50], wordWrap: true });
    tempTable.push(['Main CPU Temperature', temperatures.main + '°C']);
    temperatures.cores.forEach((coreTemp, index) => {
      tempTable.push([`Core ${index + 1} Temperature`, coreTemp + '°C']);
    });

    console.log('Operating System Information:');
    console.log(osTable.toString());

    console.log('\nBIOS Information:');
    console.log(biosTable.toString());

    console.log('\nCPU Information:');
    console.log(cpuTable.toString());

    console.log('\nMemory Information:');
    console.log(memTable.toString());

    console.log('\nDisk Information:');
    console.log(disksTable.toString());

    console.log('\nBattery Information:');
    console.log(batteryTable.toString());

    console.log('\nNetwork Interfaces:');
    console.log(networkTable.toString());

    console.log('\nRunning Processes:');
    console.log(processTable.toString());

    console.log('\nCPU Temperatures:');
    console.log(tempTable.toString());

    console.log('\nEnd of Extended System Information');
  } catch (error) {
    console.error('Error fetching system information:', error);
  }
})();
