const os = require('os');
const osUtils = require('os-utils');
const si = require('systeminformation');
const { exec } = require('child_process');

(async () => {
  try {
    const osInfo = await si.osInfo();
    console.log('Operating System Information:');
    console.log('  Platform:', osInfo.platform);
    console.log('  Distribution:', osInfo.distro);
    console.log('  Release:', osInfo.release);
    console.log('  Kernel Version:', osInfo.kernel);

    const bios = await si.bios();
    console.log('\nBIOS Information:');
    console.log('  Vendor:', bios.vendor);
    console.log('  Version:', bios.version);


    const cpu = await si.cpu();
    console.log('\nCPU Information:');
    console.log('  Manufacturer:', cpu.manufacturer);
    console.log('  Brand:', cpu.brand);
    console.log('  Cores:', cpu.cores);
    console.log('  Speed:', cpu.speed + ' GHz');

    const mem = await si.mem();
    console.log('\nMemory Information:');
    console.log('  Total Memory:', (mem.total / (1024 ** 3)).toFixed(2) + ' GB');
    console.log('  Free Memory:', (mem.free / (1024 ** 3)).toFixed(2) + ' GB');

    const disks = await si.diskLayout();
    console.log('\nDisk Information:');
    disks.forEach((disk, index) => {
      console.log(`  Disk ${index + 1}:`);
      console.log('    Name:', disk.name);
      console.log('    Type:', disk.type);
      console.log('    Size:', (disk.size / (1024 ** 3)).toFixed(2) + ' GB');
    });

    const battery = await si.battery();
    if (battery.hasbattery) {
      console.log('\nBattery Information:');
      console.log('  Manufacturer:', battery.manufacturer);
      console.log('  Model:', battery.model);
      console.log('  Capacity:', battery.capacity);
      console.log('  Status:', battery.ischarging ? 'Charging' : 'Discharging');
    }

    const networkInterfaces = os.networkInterfaces();
    console.log('\nNetwork Interfaces:');
    Object.keys(networkInterfaces).forEach((iface) => {
      console.log(`  ${iface}:`);
      networkInterfaces[iface].forEach((details) => {
        console.log(`    ${details.family} - ${details.address}`);
      });
    });

    console.log('\nSystem Uptime:');
    console.log('  Uptime:', os.uptime(), 'seconds');

    console.log('\nUser Information:');
    console.log('  User:', os.userInfo().username);

    osUtils.cpuUsage(function (cpuUsage) {
      console.log('\nCPU Usage:');
      console.log('  CPU Usage:', (cpuUsage * 100).toFixed(2) + '%');
    });

    osUtils.cpuFree(function (cpuFree) {
      console.log('\nCPU Free:');
      console.log('  CPU Free:', (cpuFree * 100).toFixed(2) + '%');
    });
    const totalMemory = os.totalmem();
    const freeMemory = os.freemem();
    const usedMemory = totalMemory - freeMemory;
    const memoryUsagePercentage = (usedMemory / totalMemory) * 100;
    console.log('\nMemory Usage:');
    console.log('  Memory Usage:', memoryUsagePercentage.toFixed(2) + '%');

    console.log('\nLoad Average:');
    console.log('  1 minute Load Average:', os.loadavg()[0]);
    console.log('  5 minute Load Average:', os.loadavg()[1]);
    console.log('  15 minute Load Average:', os.loadavg()[2]);

    const uptime = os.uptime();
    const uptimeHours = Math.floor(uptime / 3600);
    const uptimeMinutes = Math.floor((uptime % 3600) / 60);
    const uptimeSeconds = uptime % 60;
    console.log('\nSystem Uptime (Formatted):');
    console.log(`  Uptime: ${uptimeHours} hours, ${uptimeMinutes} minutes, ${uptimeSeconds} seconds`);

    const processList = await si.processes();
    console.log('\nRunning Processes:');
    console.log('  Number of Processes:', processList.all);
    console.log('  Running:', processList.running);
    console.log('  Sleeping:', processList.sleeping);

    const temperatures = await si.cpuTemperature();
    if (temperatures) {
      console.log('\nCPU Temperatures:');
      console.log('  Main:', temperatures.main + '°C');
      temperatures.cores.forEach((coreTemp, index) => {
        console.log(`  Core ${index + 1}:`, coreTemp + '°C');
      });
    }

    console.log('\nChild Processes Information:');
    exec('ps -eo pid,ppid,cmd,%mem,%cpu --sort=-%cpu | head -n 10', (err, stdout, stderr) => {
      if (err) {
        console.error('Error fetching child processes information:', err);
        return;
      }
      console.log(stdout);
    });

    si.networkStats().then((netStats) => {
      console.log('\nNetwork Stats:');
      console.log('  Received:');
      console.log(`    Bytes: ${netStats.rx_bytes}`);
      console.log(`    Packets: ${netStats.rx_packets}`);
      console.log('  Transmitted:');
      console.log(`    Bytes: ${netStats.tx_bytes}`);
      console.log(`    Packets: ${netStats.tx_packets}`);
    }).catch((error) => {
      console.error('Error fetching network stats:', error);
    });
    si.fsSize().then((fsList) => {
      console.log('\nFilesystem Information:');
      fsList.forEach((fs, index) => {
        console.log(`  Filesystem ${index + 1}:`);
        console.log('    Device:', fs.fs);
        console.log('    Type:', fs.type);
        console.log('    Size:', (fs.size / (1024 ** 3)).toFixed(2) + ' GB');
      });
    }).catch((error) => {
      console.error('Error fetching filesystem information:', error);
    });

    console.log('\nEnd of Extended System Information');
  } catch (error) {
    console.error('Error fetching system information:', error);
  }
})();
