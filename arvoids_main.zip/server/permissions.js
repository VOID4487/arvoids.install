module.exports = [
    {
        "key": process.env.ARVOIDS_BETA_KEY_1,
        "discordID": "0",
        "nameColor": "#ffffff",
        "class": "developer",
        "infiniteLevelUp": true,
        "name": "unnamed#0000",
        "note": "note here"
    },
    {
        "key": process.env.ARVOIDS_BETA_KEY_2,
        "discordID": "1",
        "nameColor": "#ff0000",
        "class": "developer",
        "infiniteLevelUp": false,
        "name": "user1#0000",
        "note": "note here"
    },
    {
        "key": process.env.ARVOIDS_BETA_KEY_3,
        "discordID": "2",
        "nameColor": "#00ff00",
        "class": "developer",
        "infiniteLevelUp": false,
        "name": "user2#0000",
        "note": "note here"
    },
    {
        "key": process.env.ARVOIDS_BETA_KEY_4,
        "discordID": "3",
        "nameColor": "#0000ff",
        "class": "developer",
        "infiniteLevelUp": false,
        "name": "user3#0000",
        "note": "note here"
    },
    {
        "key": process.env.ARVOIDS_BETA_KEY_5,
        "discordID": "4",
        "nameColor": "#ffff00",
        "class": "developer",
        "infiniteLevelUp": false,
        "name": "user4#0000",
        "note": "note here"
    },
    {
        "key": process.env.ARVOIDS_BETA_KEY_6,
        "discordID": "5",
        "nameColor": "#ff00ff",
        "class": "developer",
        "infiniteLevelUp": false,
        "name": "user5#0000",
        "note": "note here"
    },
    {
        "key": process.env.ARVOIDS_BETA_KEY_7,
        "discordID": "6",
        "nameColor": "#00ffff",
        "class": "developer",
        "infiniteLevelUp": false,
        "name": "user6#0000",
        "note": "note here"
    },
    {
        "key": process.env.ARVOIDS_BETA_KEY_8,
        "discordID": "7",
        "nameColor": "#9900ff",
        "class": "developer",
        "infiniteLevelUp": false,
        "name": "user7#0000",
        "note": "note here"
    },
    {
        "key": process.env.ARVOIDS_BETA_KEY_9,
        "discordID": "8",
        "nameColor": "#ff9900",
        "class": "developer",
        "infiniteLevelUp": false,
        "name": "user8#0000",
        "note": "note here"
    },
    {
        "key": process.env.ARVOIDS_BETA_KEY_10,
        "discordID": "9",
        "nameColor": "#0099ff",
        "class": "developer",
        "infiniteLevelUp": false,
        "name": "user9#0000",
        "note": "note here"
    }
]
