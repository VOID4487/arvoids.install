// you can edit this!
let teams = 4;

module.exports = {
    MODE: "tdm",
    TEAMS: teams
};