module.exports = {
    ARENA_TYPE: "circle",
    SPACE_MODE: true,
};